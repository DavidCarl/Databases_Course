# Task-1

## Installation

### Local

I would do it this way to run it on you local computer.

```wget here!```

### Docker

To come later!

## Usage

### Save to DB file
```python main.py save -k <key_value> -v <value_here>```

### Read from DB file
```python main.py read -k <key_value>```

### Help Commands
 ```python main.py --help```
 ```python main.py save --help```
 ```python main.py read --help```
